@extends('students.layout')
@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Task Students CRUD</h2>
                    </div>
                    <div class="card-body">
                        <a href="{{ url('/student/create') }}" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Country</th>
                                        <th>Subjects</th>

                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($students as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->name }}</td>
                                        <td>{{ $item->email }}</td>
                                        <td>{{ $item->phone }}</td>
                                        <td>{{ $item->address }}</td>
                                        <td>{{ $item->city }}</td>
                                        <td>{{ $item->state }}</td>
                                        <td>{{ $item->country }}</td>
<td>
                        @foreach ($item->subjects as $subject)
                            {{ $subject->name }} (Marks: {{ $subject->marks_scored }}, Grade: {{ $subject->grade }})<br>
                        @endforeach
                    </td>

                                        <td>{{ $item->status }}
                                            <button class="btn btn-primary" onclick="toggleStudentStatus({{ $item->id }})">
                                                {{ $item->status === 1 ? 'Disable' : 'Enable' }}
                                            </button>

                                        </td>

                                        <td>
                                            <a href="{{ url('/student/' . $item->id) }}" title="View Student"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="{{ url('/student/' . $item->id . '/edit') }}" title="Edit Student"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                                            <form method="POST" action="{{ url('/student' . '/' . $item->id) }}" accept-charset="UTF-8" style="display:inline">
                                                {{ method_field('DELETE') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Student" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


<script>
    function toggleStudentStatus(studentId) {
        $.ajax({
            type: 'POST',
            url: `/students/${studentId}/toggle-status`,
            data: {
                _token: '{{ csrf_token() }}',
            },
            success: function (response) {
                if (response.status === 1) {
                    // Update the UI to indicate that the student is enabled (e.g., set a class)
                    button.text('Disable');
                    button.addClass('btn btn-danger'); // Add a class for success button style
                    button.removeClass('btn btn-success');
                } else {
                    // Update the UI to indicate that the student is disabled (e.g., set a different class)
                    button.text('Enable');
                    button.addClass('btn btn-success'); // Add a class for danger button style
                    button.removeClass('btn btn-danger');
                }
            },
        });
    }
</script>
