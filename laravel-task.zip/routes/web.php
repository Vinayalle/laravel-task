<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;


Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::resource("/student", StudentController::class);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::prefix('admin')->group(function(){
    Route::get('/dashboard',[App\Http\Controllers\Admin\DashboardController::class , 'index']);
});

Route::post('/students/{student}/toggle-status', [App\Http\Controllers\StudentController::class, 'toggleStatus'])->name('students.toggle-status');


