
@extends('students.layout')
@section('content')

<div class="card">
  <div class="card-header">Contactus Page</div>
  <div class="card-body">

      <form action="{{ url('student/' .$students->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$students->id}}" id="id" />

        <label>Name</label></br>
        <input type="text" name="name" id="name" value="{{$students->name}}" class="form-control"></br>
        <label>email</label></br>
        <input type="email" name="email" id="email"  value="{{$students->email}}" class="form-control"></br>
        <label>phone</label></br>
        <input type="text" name="phone" id="phone" value="{{$students->phone}}" class="form-control"></br>
        <label>address</label></br>
        <input type="text" name="address" id="address" value="{{$students->address}}" class="form-control"></br>
        <label>city</label></br>
        <input type="text" name="city" id="city" value="{{$students->city}}" class="form-control"></br>
        <label>state</label></br>
        <input type="text" name="state" id="state" value="{{$students->state}}" class="form-control"></br>
        <label>country</label></br>
        <input type="text" name="country" id="country" value="{{$students->country}}" class="form-control"></br>
        <label>status</label></br>
        <input type="number" name="status" id="status" value="{{$students->status}}" class="form-control"></br>



        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>

  </div>
</div>

@stop
