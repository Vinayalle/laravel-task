@extends('students.layout')
@section('content')

<div class="card">
  <div class="card-header">Students Page</div>
  <div class="card-body">

      <form action="{{ url('student') }}" method="post">
        {!! csrf_field() !!}
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <label>email</label></br>
        <input type="email" name="email" id="email" class="form-control"></br>
        <label>phone</label></br>
        <input type="text" name="phone" id="phone" class="form-control"></br>
        <label>address</label></br>
        <input type="text" name="address" id="address" class="form-control"></br>
        <label>city</label></br>
        <input type="text" name="city" id="city" class="form-control"></br>
        <label>state</label></br>
        <input type="text" name="state" id="state" class="form-control"></br>
        <label>country</label></br>
        <input type="text" name="country" id="country" class="form-control"></br>
        <label>status</label></br>
        <input type="number" name="status" id="status" class="form-control"></br>
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>

  </div>
</div>

@stop
